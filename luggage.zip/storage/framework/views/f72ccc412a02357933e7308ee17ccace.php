<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('frontend/css/toastr.css')); ?>" />
<?php $__env->stopPush(); ?>


<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('frontend/js/toastr.min.js')); ?>"></script>
<?php if(Session::has('success')): ?>
    <script>
        toastr.success("<?php echo e(Session::get('success')); ?>")
    </script>
<?php elseif(!empty(Session::get('error'))): ?>
    <script>
        toastr.error("<?php echo e(Session::get('error')); ?>")
    </script>
<?php endif; ?>

<?php $__env->stopPush(); ?><?php /**PATH C:\laragon\www\luggage\resources\views/frontend/include/head.blade.php ENDPATH**/ ?>