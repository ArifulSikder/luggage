<input type="hidden" id="base_url" name="base_url" value="<?php echo e(asset('assets')); ?>/">
<header>
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('assets')); ?>/img/logo.png"
                    alt="Luggage hub"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="#">All Cities</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">How it works</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">Pricing</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">About</a></li>
                    <li class="nav-item"><a class="nav-link p180" href="<?php echo e(route('login')); ?>">Become
                            a partner</a></li>
                    <?php if(Route::has('login')): ?>
                        <?php if(auth()->guard()->check()): ?>
                            <li class="nav-item"><a class="nav-link login" href="#">Hello !
                                    <?php echo e(Auth::user()->name); ?></a></li>
                            <li class="nav-item">
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                                <a class="btn btn-primary" href="#"
                                    onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout
                                    →</a>
                            </li>
                        <?php else: ?>
                            <li class="nav-item"><a class="nav-link login" href="<?php echo e(route('login')); ?>">Login</a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item"><a class="btn btn-primary" href="<?php echo e(route('register')); ?>">Sing
                                        up →</a></li>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
</header>
<?php /**PATH C:\laragon\www\luggage\resources\views/frontend/include/header.blade.php ENDPATH**/ ?>